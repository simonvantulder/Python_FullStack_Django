from django.shortcuts import render
from time import mktime, strftime, localtime, gmtime

def index(request):
    context = {
        "time" : strftime("%B-%d-%Y", localtime()),
        "time2" : strftime("%H:%M %p", localtime())
    }
    return render(request, "index.html", context)


