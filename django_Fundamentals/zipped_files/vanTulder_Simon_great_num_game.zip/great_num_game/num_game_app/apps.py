from django.apps import AppConfig


class NumGameAppConfig(AppConfig):
    name = 'num_game_app'
