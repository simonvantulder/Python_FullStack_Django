from django.apps import AppConfig


class AuthorsAppConfig(AppConfig):
    name = 'authors_app'
