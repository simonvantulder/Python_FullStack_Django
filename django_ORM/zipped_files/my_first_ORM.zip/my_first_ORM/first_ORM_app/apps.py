from django.apps import AppConfig


class FirstOrmAppConfig(AppConfig):
    name = 'first_ORM_app'
