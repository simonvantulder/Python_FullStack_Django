from django.db import models
from wall_app.models import *
# Create your models here.
