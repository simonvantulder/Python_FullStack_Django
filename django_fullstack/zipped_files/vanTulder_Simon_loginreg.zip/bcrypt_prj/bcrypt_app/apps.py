from django.apps import AppConfig


class BcryptAppConfig(AppConfig):
    name = 'bcrypt_app'
