from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),# path in quotes and method name after views (in this case method = index)
    path('user/register', views.user_create),# path in quotes and method name after views (in this case method = index)
    path('user/<int:id>', views.user_page),
    path('login', views.login),
    path('user/add_trips/<int:id>', views.user_add_trip),
    path('user/leave_trips/<int:id>', views.user_leave_trip),

    path('dashboard', views.dashboard),
    path('trips/add', views.trips_add),
    path('trips/trips/create', views.trip_create),
    path('trips/<int:id>', views.trips_page),
    path('trips/<int:id>/edit', views.trips_edit),
    path('trips/<int:id>/update', views.trip_update),
    path('trips/<int:id>/delete', views.delete_trip),

    path('logout', views.logout),

]

