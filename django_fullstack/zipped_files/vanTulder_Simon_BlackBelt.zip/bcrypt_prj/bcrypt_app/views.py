from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from . models import *

def index(request):
    return render (request, "index.html")


def user_create(request):
    errors = User.objects.validator(request.POST)
    
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/")
    else:
        hash_browns = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
        user = User.objects.create(
            first_name = request.POST["first_name"],
            last_name = request.POST["last_name"],
            birthday = request.POST["birthday"],
            email = request.POST["email"],
            password = hash_browns,
            )
        request.session['uuid'] = user.id

    return redirect ("/dashboard")



def user_page(request, id):
    if 'uuid' not in request.session:
        return redirect("/")
    this_user = User.objects.get(id = id)
    context = {

    }
    return render (request, "user_page.html", context)


def login(request):
    errors = User.objects.login_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/")
    else:
        user_list = User.objects.filter(email = request.POST['email'])
        user = user_list[0]
        request.session['uuid'] = user.id 

        return redirect("/dashboard")


def user_add_trip(request, id):
    this_user= User.objects.get(id= request.session["uuid"])
    this_trip = Trip.objects.get(id=request.POST["ISBN"])
    this_user.trips.add(this_trip)

    return redirect("/dashboard")


def user_leave_trip(request, id):
    this_user= User.objects.get(id= request.session["uuid"])
    this_trip = Trip.objects.get(id=request.POST["ISBN"])
    this_user.trips.remove(this_trip)

    return redirect("/dashboard")


def logout(request):
    del request.session['uuid']
    
    return redirect("/")


def dashboard(request):
    if 'uuid' not in request.session:
        return redirect("/")
    else:
        user_num = int(request.session['uuid'])
        this_user = User.objects.get(id = request.session['uuid'])
        joined_trips = this_user.trips.all()
        all_trips = Trip.objects.all()
        other_trips = []
        for trip in all_trips:
            for jtrip in joined_trips:
                if jtrip.id != trip.id:
                    other_trips.append(jtrip)
        context = {
            'user': User.objects.get(id = request.session['uuid']),
            'trips':Trip.objects.exclude(leader=user_num),
            # 'trips':other_trips
        }
        return render (request, "dashboard.html", context)


def trips_page(request, id):
    if 'uuid' not in request.session:
        return redirect("/")
    context = {
        "trip" : Trip.objects.get(id = id),
        "user" : User.objects.get(id = request.session['uuid']),
    }
    return render (request, "trips_page.html", context)



def trips_add(request):
    if 'uuid' not in request.session:
        return redirect("/")
    this_user = User.objects.get(id = request.session['uuid'])
    context = {
        'user': User.objects.get(id = request.session['uuid'])
        }
    return render(request, "trips_add.html", context)


def trip_create(request):
    errors = User.objects.new_trip_validator(request.POST)
    
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/trips/add")
    else:
        trip = Trip.objects.create(
            leader = User.objects.get(id = request.session['uuid']),
            destination = request.POST["destination"],
            start_date = request.POST["start_date"],
            end_date = request.POST["end_date"],
            plan = request.POST["plan"],

        )

    return redirect ("/dashboard")


def trips_edit(request, id):
    if 'uuid' not in request.session:
        return redirect("/")
    
    this_user = User.objects.get(id = request.session['uuid'])
    this_trip = Trip.objects.get(id = id)

    context = {
        'trip': this_trip,
        'user': User.objects.get(id = request.session['uuid'])

    }

    return render(request, "trips_edit.html", context)


def trip_update(request, id):
    errors = User.objects.new_trip_validator(request.POST)
    
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect(f"/trips/{id}/edit")
    else:

        trip = Trip.objects.get(id = id)
        trip.destination = request.POST['destination']
        trip.start_date = request.POST['start_date']
        trip.end_date = request.POST['end_date']
        trip.plan = request.POST['plan']
        trip.save()

    return redirect ("/dashboard")


def delete_trip(request, id):
    this_trip = Trip.objects.get(id = id)
    this_trip.delete()

    return redirect("/dashboard")